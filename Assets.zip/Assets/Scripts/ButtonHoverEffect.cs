using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class ButtonHoverEffect : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    public Text buttonText;  // Reference to the button's text component
    public Color normalColor = Color.white;  // Normal text color
    public Color hoverColor = Color.yellow;   // Hover text color

    private Material originalMaterial;

    void Start()
    {
        // Set the initial color of the button text
        if (buttonText != null)
        {
            buttonText.color = normalColor;
            originalMaterial = buttonText.material;  // Save the original material in case you modify it
        }
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        // Change the color to hover color
        if (buttonText != null)
        {
            buttonText.color = hoverColor;

            // Optionally, make the text glow if you have a material that supports glow
            Material glowMaterial = buttonText.material;
            if (glowMaterial.HasProperty("_GlowIntensity"))  // Check if the material has a glow property
            {
                glowMaterial.SetFloat("_GlowIntensity", 1.5f);  // Set glow intensity (if applicable)
            }
        }
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        // Reset the color to normal
        if (buttonText != null)
        {
            buttonText.color = normalColor;

            // Reset glow effect if applicable
            if (originalMaterial.HasProperty("_GlowIntensity"))
            {
                originalMaterial.SetFloat("_GlowIntensity", 0);  // Reset glow intensity
            }
        }
    }
}
