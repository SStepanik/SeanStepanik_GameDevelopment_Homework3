using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.InputSystem;


public class TileCheckerBySprite : MonoBehaviour
{
    public Tilemap tilemap;  // Reference to the Tilemap
    public List<GameObject> specificObjects;  // List of the specific objects to check
    public List<Sprite> requiredTileSprites;  // List of required tile sprites
    public Vector3 objectOffset = new Vector3(0.5f, 0.5f, 0);  // Offset adjustment (if objects are centered on tiles)
    public float delayTime = 2f;

    void Update()
    {
        // Check if all objects are on tiles with the correct sprites
        if (AreObjectsOnCorrectTiles())
        {
            // All objects are on the correct tiles, change the scene
            Invoke("ChangeScene", delayTime);
            //ChangeScene();
        }
    }

    bool AreObjectsOnCorrectTiles()
    {
        for (int i = 0; i < specificObjects.Count; i++)
        {
            GameObject obj = specificObjects[i];

            // Adjust the object's world position by subtracting the offset
            Vector3 adjustedObjectPosition = obj.transform.position - objectOffset;

            // Convert the adjusted world position to grid position
            Vector3Int objectPositionOnGrid = tilemap.WorldToCell(adjustedObjectPosition);

            // Get the tile at the object's grid position
            TileBase tile = tilemap.GetTile(objectPositionOnGrid);

            // Check if there's a tile at that position and if its sprite matches the required sprite
            if (tile == null || !IsTileSpriteCorrect(tile, requiredTileSprites[i]))
            {
                return false;  // Either no tile, or the tile doesn't match the required sprite
            }
        }

        return true;  // All objects are on tiles with the correct sprites
    }

    bool IsTileSpriteCorrect(TileBase tile, Sprite requiredSprite)
    {
        // Assuming the tile is a Tile object with a sprite property
        Tile tileObject = tile as Tile;

        if (tileObject != null && tileObject.sprite != null)
        {
            // Check if the tile's sprite matches the required sprite
            return tileObject.sprite == requiredSprite;
        }

        return false;
    }

    void  ChangeScene()
    {
        // Get the currently active scene
        Scene currentScene = SceneManager.GetActiveScene();

        // Calculate the next scene index
        int nextSceneIndex = currentScene.buildIndex + 1;

        // Check if the next scene index exceeds the total number of scenes
        if (nextSceneIndex >= SceneManager.sceneCountInBuildSettings)
        {
            // If it exceeds, loop back to the first scene
            nextSceneIndex = 0; // or use a specific index if you have a main menu
        }

        // Load the next scene using its build index
        SceneManager.LoadScene(nextSceneIndex);
    }
}
