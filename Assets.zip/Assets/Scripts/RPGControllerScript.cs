using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.InputSystem;
using UnityEngine.Tilemaps;
using System;

public class RPGControl : MonoBehaviour
{
    public float speed;
    private Vector2 movement;
    public Tilemap map;
    public Transform targetPosition;
    public LayerMask UnwalkableLayer;
    public LayerMask MoveableLayer;
    public Button redoBtn;
    Animator animator;
    private float horizontal;
    private bool isFacingRight = true;
    bool isnotmovingvertical = true;

    private void Awake() {
        targetPosition.position = transform.position;
        redoBtn.onClick.AddListener(() => RedoBtnClicked());
        animator = GetComponent<Animator>();
    }

    private void FixedUpdate() {
        animator.SetFloat("Xvelocity", movement.x);
        animator.SetFloat("Yvelocity", movement.y);
    }
    // Update is called once per frame
    void Update()
    {
        if(movement.y != 0)
        {
            isnotmovingvertical = false;
        } else 
        {
            isnotmovingvertical = true;
        }

        if (Vector3.Distance(transform.position, targetPosition.position) < .01f && !Physics2D.OverlapCircle(targetPosition.position + new Vector3(movement.x, movement.y, 0f), .1f, UnwalkableLayer)) 
        {
            if (Physics2D.OverlapCircle(targetPosition.position + new Vector3(movement.x, movement.y, 0f), .1f, MoveableLayer))
            {
                if (!Physics2D.OverlapCircle(targetPosition.position + new Vector3(2*movement.x, 2*movement.y, 0f), .1f, UnwalkableLayer))
                {
                    targetPosition.position = new Vector3(targetPosition.position.x + movement.x, targetPosition.position.y + movement.y, 0f);
                }
            } else 
            {
                targetPosition.position = new Vector3(targetPosition.position.x + movement.x, targetPosition.position.y + movement.y, 0f);
            }
        }
        
        if (isFacingRight && movement.x < 0f) Flip();
        if (!isFacingRight && movement.x > 0f) Flip();
        animator.SetFloat("Xvelocity", movement.x);
        animator.SetFloat("Yvelocity", movement.y);
        animator.SetBool("isVert", !isnotmovingvertical);
        transform.position = Vector3.MoveTowards(transform.position, targetPosition.position, speed * Time.deltaTime);
        
    }

    void OnMove(InputValue value) {
        movement = value.Get<Vector2>();
    }
    private void OnCollisionEnter2D(Collision2D other) {
        if (other.gameObject.CompareTag("Key"))
        {
            other.gameObject.transform.position = new Vector3(targetPosition.position.x + movement.x, targetPosition.position.y + movement.y, 0f);
        }
    }
    private void RedoBtnClicked()
    {
        // Get the currently active scene
        Scene currentScene = SceneManager.GetActiveScene();

        // Reload the scene using the scene name or build index
        SceneManager.LoadScene(currentScene.name);
    }

    private void Flip() {
        isFacingRight = !isFacingRight;
        //transform.eulerAngles = new Vector3(transform.eulerAngles.x, transform.eulerAngles.y + 180, transform.eulerAngles.z);
        Vector3 localScale = transform.localScale;
        localScale.x *= -1;
        transform.localScale = localScale;
    }
}
