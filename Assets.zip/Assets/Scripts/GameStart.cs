using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.InputSystem;

public class GameStart : MonoBehaviour
{
    // Start is called before the first frame update
    public Button startGameBtn;

    private void Awake() {
        startGameBtn.onClick.AddListener(() => StartGameBtnClicked());
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void  StartGameBtnClicked()
    {
        // Get the currently active scene
        Scene currentScene = SceneManager.GetActiveScene();

        // Calculate the next scene index
        int nextSceneIndex = currentScene.buildIndex + 1;

        // Check if the next scene index exceeds the total number of scenes
        if (nextSceneIndex >= SceneManager.sceneCountInBuildSettings)
        {
            // If it exceeds, loop back to the first scene
            nextSceneIndex = 0; // or use a specific index if you have a main menu
        }

        // Load the next scene using its build index
        SceneManager.LoadScene(nextSceneIndex);
    }
}
